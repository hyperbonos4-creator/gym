import { NextResponse } from "next/server";
import { socioFromMobileRequest } from "../../../../lib/mobileSession";
import { EXERCISES } from "../../../../lib/exercisesCatalog";
import { movementPayload } from "../../../../lib/movement";
import { listAssignedExercises } from "../../../../lib/exerciseAssignments";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const session = socioFromMobileRequest(req);
  if (!session) return NextResponse.json({ ok: false, error: "Sesión vencida." }, { status: 401 });
  const assigned = listAssignedExercises(session.gymId, session.socio.id);
  const items = assigned.flatMap((row) => {
    const exercise = EXERCISES.find((e) => e.id === row.exerciseId);
    if (!exercise) return [];
    return [{
      ...movementPayload(exercise),
      sentAt: row.sentAt,
    }];
  });
  return NextResponse.json({ ok: true, items });
}
