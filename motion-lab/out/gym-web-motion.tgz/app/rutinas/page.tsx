"use client";

import { useCallback, useEffect, useState } from "react";
import GymShell from "../../components/GymShell";
import { draftOf, latestPublished, trainingDays, type RoutineTemplate } from "../../lib/routineTypes";
import { getActiveGymId } from "../../lib/session";

export default function RutinasPage() {
  const [items, setItems] = useState<RoutineTemplate[] | null>(null);
  const [goal, setGoal] = useState("Todos");

  const load = useCallback(async (id: string) => {
    const res = await fetch(`/api/routines?gym=${encodeURIComponent(id)}`, { cache: "no-store" });
    const data = await res.json();
    setItems(data.items || []);
  }, []);

  useEffect(() => {
    load(getActiveGymId() || "fuerza-elite");
  }, [load]);

  const goals = ["Todos", ...Array.from(new Set((items || []).map((t) => t.goal)))];
  const visible = (items || []).filter((t) => goal === "Todos" || t.goal === goal);
  const published = (items || []).filter((t) => latestPublished(t)).length;
  const drafts = (items || []).filter((t) => draftOf(t)).length;

  return (
    <GymShell active="rutinas">
      <div className="px-6 py-6">
        <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-xl font-extrabold text-white">Centro de entrenamiento</h2>
            <p className="text-sm text-gym-muted">Plantillas de esta sede. El entrenador arma el plan. Asignarlo al socio es el paso que sigue.</p>
          </div>
          <a href="/rutinas/crear" className="btn-gym">Crear rutina</a>
        </div>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            ["Plantillas", items ? String(items.length) : "—"],
            ["Publicadas", items ? String(published) : "—"],
            ["Borradores", items ? String(drafts) : "—"],
            ["Asignaciones vigentes", "—"],
          ].map(([l, v]) => (
            <div key={l} className="glass-soft px-4 py-3">
              <div className="text-[11px] text-gym-muted">{l}</div>
              <div className="text-2xl font-extrabold text-white">{v}</div>
            </div>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-gym-muted">Socios asignados, revisión y adherencia se quedan en blanco hasta que exista la asignación. No son ceros.</p>

        <section className="mt-6">
          <h3 className="text-sm font-bold text-white">Biblioteca</h3>
          <div className="mt-3 flex flex-wrap gap-2">
            {goals.map((g) => (
              <button key={g} type="button" onClick={() => setGoal(g)} className={`rounded-full px-3 py-1 text-xs font-semibold ${goal === g ? "bg-gym-primary text-gym-navy" : "border border-gym-border text-gym-muted"}`}>{g}</button>
            ))}
          </div>
          {items === null && <p className="mt-4 text-sm text-gym-muted">Leyendo plantillas…</p>}
          {items && visible.length === 0 && <p className="mt-4 text-sm text-gym-muted">Todavía no hay plantillas en esta sede.</p>}
          <ul className="mt-3 grid gap-3 md:grid-cols-2">
            {visible.map((t) => {
              const pub = latestPublished(t);
              const draft = draftOf(t);
              const days = (pub || draft)?.days || [];
              return (
                <li key={t.id}>
                  <a href={`/rutinas/${t.id}`} className="glass block p-4 hover:border-gym-primary/50">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="font-extrabold text-white">{t.name}</div>
                        <div className="mt-1 text-xs text-gym-muted">{t.goal} · {t.level} · {trainingDays(days)} días / semana</div>
                      </div>
                      <span className={`text-[11px] font-semibold ${draft ? "text-status-warn" : "text-status-ok"}`}>{draft ? "Borrador" : "Publicada"}</span>
                    </div>
                    <div className="mt-3 text-[11px] text-gym-muted">
                      {pub ? `Versión ${pub.number} publicada` : "Sin publicar"}
                      {draft && pub ? ` · versión ${draft.number} en borrador` : ""}
                    </div>
                  </a>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="mt-8">
          <h3 className="text-sm font-bold text-white">Trabajo pendiente</h3>
          <ul className="mt-3 grid gap-3 md:grid-cols-3">
            {[
              ["Socios sin rutina", "Aparece cuando se pueda asignar un plan a un socio activo."],
              ["Rutinas por revisar", "Aparece cuando una versión publicada tenga fecha de revisión."],
              ["Planes sin entregar", "Aparece cuando el socio pueda abrir el plan desde su enlace."],
            ].map(([t, d]) => (
              <li key={t} className="rounded-xl border border-gym-border/70 px-4 py-3">
                <div className="text-sm font-semibold text-white">{t}</div>
                <p className="mt-1 text-xs text-gym-muted">{d}</p>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </GymShell>
  );
}
