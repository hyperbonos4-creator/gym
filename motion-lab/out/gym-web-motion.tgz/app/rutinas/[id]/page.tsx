"use client";

import { useEffect, useState } from "react";
import GymShell from "../../../components/GymShell";
import { ExecutionPeek } from "../../../components/routines/ExecutionPeek";
import { EXERCISES } from "../../../lib/exercisesCatalog";
import { MUSCLE_BY_ID } from "../../../lib/muscles";
import { draftOf, latestPublished, trainingDays, type RoutineTemplate } from "../../../lib/routineTypes";
import { getActiveGymId } from "../../../lib/session";

const KIND: Record<string, string> = {
  ejercicio: "Ejercicio",
  superserie: "Superserie",
  circuito: "Circuito",
  calentamiento: "Calentamiento",
};

export default function RutinaPage({ params }: { params: { id: string } }) {
  const [template, setTemplate] = useState<RoutineTemplate | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const id = getActiveGymId() || "fuerza-elite";
    fetch(`/api/routines/${params.id}?gym=${encodeURIComponent(id)}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (!d.ok) setError(d.error || "No está en esta sede.");
        else setTemplate(d.template);
      })
      .catch(() => setError("No se pudo leer la plantilla."));
  }, [params.id]);

  const shown = template ? latestPublished(template) || draftOf(template) : null;

  return (
    <GymShell active="rutinas">
      <div className="px-6 py-6">
        <a href="/rutinas" className="text-xs font-semibold text-gym-primary">Biblioteca</a>
        {error && <p className="mt-4 text-sm text-status-err">{error}</p>}
        {!template && !error && <p className="mt-4 text-sm text-gym-muted">Leyendo la plantilla…</p>}
        {template && shown && (
          <>
            <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="text-2xl font-extrabold text-white">{template.name}</h2>
                <p className="mt-1 text-sm text-gym-muted">
                  {template.goal} · {template.level} · {trainingDays(shown.days)} días / semana · versión {shown.number} {shown.status}
                </p>
              </div>
              <a href={`/rutinas/${template.id}/editar`} className="btn-gym">{draftOf(template) ? "Seguir el borrador" : "Nueva versión"}</a>
            </div>
            {latestPublished(template) && draftOf(template) && (
              <p className="mt-3 text-xs text-status-warn">Hay un borrador más nuevo. Lo que ves es la última versión publicada.</p>
            )}
            <div className="mt-5 flex flex-col gap-4">
              {shown.days.map((d) => (
                <section key={d.id} className="glass p-4">
                  <h3 className="font-extrabold text-white">{d.label} · {d.rest ? "Descanso" : d.title}</h3>
                  {d.rest && <p className="mt-2 text-sm text-gym-muted">Sin ejercicios.</p>}
                  <div className="mt-3 flex flex-col gap-3">
                    {d.blocks.map((b) => (
                      <div key={b.id}>
                        <div className="text-[11px] font-semibold uppercase tracking-wide text-gym-muted">{KIND[b.kind] || b.kind}</div>
                        <ul className="mt-1 divide-y divide-gym-border/40">
                          {b.items.map((item) => {
                            const ex = EXERCISES.find((e) => e.id === item.exerciseId);
                            const alt = EXERCISES.find((e) => e.id === item.alternativeId);
                            return (
                              <li key={item.id} className="py-2">
                                <ExecutionPeek
                                  exerciseId={item.exerciseId}
                                  prescription={{ sets: item.sets, reps: item.reps, restSec: item.restSec, tempo: item.tempo || ex?.tempo || "" }}
                                >
                                  <span className="font-semibold text-white">{ex?.name || item.exerciseId}</span>
                                </ExecutionPeek>
                                <p className="text-xs text-gym-muted">
                                  {ex ? `${MUSCLE_BY_ID[ex.primary].name} · ` : ""}
                                  {item.sets} series · {item.reps} · {item.restSec} s
                                  {item.load ? ` · carga ${item.load}` : ""}
                                  {item.effort ? ` · ${item.effort}` : ""}
                                  {item.tempo ? ` · tempo ${item.tempo}` : ""}
                                </p>
                                {alt && <p className="text-xs text-gym-muted">Alternativa: {alt.name}</p>}
                                {item.note && <p className="text-xs text-gym-silver">{item.note}</p>}
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    ))}
                  </div>
                </section>
              ))}
            </div>
            <p className="mt-4 text-[11px] text-gym-muted">Estas cifras son la prescripción. Cuando el socio registre una sesión, la carga y las repeticiones reales quedan aparte.</p>
          </>
        )}
      </div>
    </GymShell>
  );
}
