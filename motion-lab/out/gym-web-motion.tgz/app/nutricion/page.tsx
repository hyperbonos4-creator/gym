"use client";

import GymShell from "../../components/GymShell";

export default function NutricionPage() {
  return <GymShell active="nutricion">{null}</GymShell>;
}
