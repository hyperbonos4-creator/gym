"use client";

import GymShell from "../../components/GymShell";

export default function ValoracionesPage() {
  return <GymShell active="valoraciones">{null}</GymShell>;
}
