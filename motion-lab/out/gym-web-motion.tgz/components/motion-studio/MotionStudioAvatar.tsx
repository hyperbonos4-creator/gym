"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { useAnimations } from "@react-three/drei";
import { GLTFLoader, type GLTF } from "three/examples/jsm/loaders/GLTFLoader.js";
import { MeshoptDecoder } from "three/examples/jsm/libs/meshopt_decoder.module.js";
import { clone as cloneSkeleton } from "three/examples/jsm/utils/SkeletonUtils.js";
import {
  Box3,
  Color,
  AnimationMixer,
  LoopRepeat,
  Mesh,
  type AnimationClip,
  type Group,
  type Material,
  type Object3D,
  type SkinnedMesh,
  Vector3,
} from "three";
import {
  MOTION_PROP_NAMES,
  type MotionAngles,
  type MotionRigReport,
} from "../../lib/motion-studio/models";

const NO_CLIPS: AnimationClip[] = [];
const PROP_NAMES = new Set(MOTION_PROP_NAMES);

type MotionStudioAvatarProps = {
  src: string;
  scale?: number;
  y?: number;
  play: string[];
  show: string[];
  playing?: boolean;
  playbackRate?: number;
  /** 0–1 mientras se arrastra la línea de tiempo. Null sigue la reproducción. */
  scrub?: number | null;
  ghost?: boolean;
  onRigReport?: (report: MotionRigReport) => void;
  onLoadError?: (message: string) => void;
  onProgress?: (ratio: number | null) => void;
  onClock?: (time: number, duration: number) => void;
  onAngles?: (angles: MotionAngles) => void;
};

function inspectRig(scene: Object3D, clips: AnimationClip[], src: string): MotionRigReport {
  const boneNames = new Set<string>();
  const clipReports: MotionRigReport["clips"] = [];
  let meshCount = 0;
  let skinnedMeshCount = 0;

  scene.traverse((node) => {
    const skinned = node as SkinnedMesh;
    if (skinned.isSkinnedMesh) {
      skinnedMeshCount += 1;
      meshCount += 1;
    } else if ((node as { isMesh?: boolean }).isMesh) {
      meshCount += 1;
    }
    if ((node as { isBone?: boolean }).isBone) boneNames.add(node.name || "(hueso sin nombre)");
  });

  for (const clip of clips) {
    const matchingTrackCount = clip.tracks.filter((track) => {
      const target = track.name.split(".")[0]?.replace(/^\.root\./, "");
      return boneNames.has(target);
    }).length;
    clipReports.push({
      name: clip.name || "Animación sin nombre",
      durationSeconds: Number.isFinite(clip.duration) ? Math.max(0, clip.duration) : 0,
      trackCount: clip.tracks.length,
      tracksMatchingBones: matchingTrackCount,
    });
  }

  let heightInSceneUnits: number | null = null;
  try {
    const bounds = new Box3().setFromObject(scene);
    const size = new Vector3();
    bounds.getSize(size);
    if (Number.isFinite(size.y) && size.y > 0) heightInSceneUnits = Number(size.y.toFixed(3));
  } catch {
    heightInSceneUnits = null;
  }

  const warnings: string[] = [];
  if (skinnedMeshCount === 0) warnings.push("No hay una malla unida al esqueleto. Este GLB todavía no sirve para mover el cuerpo.");
  if (boneNames.size === 0) warnings.push("No hay huesos. No es un avatar articulado.");
  if (clips.length === 0) warnings.push("El GLB no trae clips. Las poses de la tienda pueden ser archivos aparte, no un ejercicio en bucle.");
  if (clips.length > 0 && clipReports.every((clip) => clip.tracksMatchingBones === 0)) {
    warnings.push("Hay clips, pero sus pistas no coinciden con los nombres de los huesos. Hay que revisar el rig antes de reproducirlos.");
  }
  if (heightInSceneUnits !== null && (heightInSceneUnits < 0.25 || heightInSceneUnits > 10)) {
    warnings.push("La altura del archivo se sale de lo esperado. Hay que revisar escala y unidades.");
  }

  return {
    src,
    rootName: scene.name || "Scene",
    meshCount,
    skinnedMeshCount,
    boneCount: boneNames.size,
    boneNames: [...boneNames].sort((a, b) => a.localeCompare(b)),
    heightInSceneUnits,
    clips: clipReports,
    warnings,
  };
}

function owningProp(node: Object3D) {
  let current: Object3D | null = node;
  while (current) {
    if (PROP_NAMES.has(current.name)) return current.name;
    current = current.parent;
  }
  return null;
}

function applyProps(root: Object3D, show: string[]) {
  const visible = new Set(show);
  root.traverse((node) => {
    const mesh = node as SkinnedMesh;
    if (!mesh.isMesh) return;
    if (mesh.isSkinnedMesh) {
      mesh.visible = true;
      return;
    }
    const owner = owningProp(mesh);
    mesh.visible = owner !== null && visible.has(owner);
  });
}

const jointA = new Vector3();
const jointB = new Vector3();
const jointC = new Vector3();

function jointDegrees(root: Object3D, hip: string, joint: string, end: string) {
  const a = root.getObjectByName(hip);
  const b = root.getObjectByName(joint);
  const c = root.getObjectByName(end);
  if (!a || !b || !c) return null;
  a.getWorldPosition(jointA);
  b.getWorldPosition(jointB);
  c.getWorldPosition(jointC);
  const u = jointA.sub(jointB).normalize();
  const v = jointC.sub(jointB).normalize();
  const dot = Math.max(-1, Math.min(1, u.dot(v)));
  return Math.round((Math.acos(dot) * 180) / Math.PI);
}

function paintGhost(root: Object3D) {
  root.traverse((node) => {
    const mesh = node as Mesh;
    if (!mesh.isMesh) return;
    const source = mesh.material;
    const materials = (Array.isArray(source) ? source : [source]).map((material) => {
      const next = material.clone();
      next.transparent = true;
      next.opacity = 0.2;
      next.depthWrite = false;
      const colored = next as Material & { color?: Color };
      if (colored.color) colored.color = new Color("#b7c7d6");
      return next;
    });
    mesh.material = Array.isArray(source) ? materials : materials[0];
  });
}

export default function MotionStudioAvatar({
  src,
  scale = 1,
  y = 0,
  play,
  show,
  playing = false,
  playbackRate = 1,
  scrub = null,
  ghost = false,
  onRigReport,
  onLoadError,
  onProgress,
  onClock,
  onAngles,
}: MotionStudioAvatarProps) {
  const mount = useRef<Group>(null);
  const clockRef = useRef({ time: 0, duration: 1 });
  const uiRef = useRef(0);
  const [loaded, setLoaded] = useState<GLTF | null>(null);

  const playKey = play.join("|");
  const showKey = show.join("|");

  useEffect(() => {
    let dead = false;
    setLoaded(null);
    onProgress?.(0);
    const loader = new GLTFLoader();
    loader.setMeshoptDecoder(MeshoptDecoder);
    MeshoptDecoder.ready
      .then(() => fetch(src))
      .then((res) => {
        if (!res.ok) throw new Error(`El archivo respondió ${res.status}.`);
        const total = Number(res.headers.get("content-length") || 0);
        const reader = res.body?.getReader();
        if (!reader) return res.arrayBuffer();
        const chunks: Uint8Array[] = [];
        let received = 0;
        const pump = async (): Promise<ArrayBuffer> => {
          const step = await reader.read();
          if (step.done) {
            const buffer = new Uint8Array(received);
            let offset = 0;
            for (const chunk of chunks) {
              buffer.set(chunk, offset);
              offset += chunk.length;
            }
            return buffer.buffer;
          }
          chunks.push(step.value);
          received += step.value.length;
          if (!dead) onProgress?.(total > 0 ? received / total : null);
          return pump();
        };
        return pump();
      })
      .then(
        (buffer) =>
          new Promise<GLTF>((resolve, reject) => {
            loader.parse(buffer, "", resolve, (err) => reject(err));
          }),
      )
      .then((parsed) => {
        if (dead) return;
        setLoaded(parsed);
        onProgress?.(1);
      })
      .catch((err: unknown) => {
        if (dead) return;
        const message = err instanceof Error ? err.message : "No se pudo leer el GLB.";
        onLoadError?.(message);
        onProgress?.(null);
      });
    return () => {
      dead = true;
    };
  }, [onLoadError, onProgress, src]);

  const avatarScene = loaded?.scene ?? null;
  const animations = loaded?.animations ?? NO_CLIPS;
  const report = useMemo(
    () => (avatarScene ? inspectRig(avatarScene, animations, src) : null),
    [avatarScene, animations, src],
  );
  const { actions, mixer } = useAnimations(animations, mount);
  const ghostScene = useMemo(() => {
    if (!ghost || !avatarScene) return null;
    const copy = cloneSkeleton(avatarScene);
    paintGhost(copy);
    return copy;
  }, [avatarScene, ghost]);
  const ghostMixer = useMemo(() => (ghostScene ? new AnimationMixer(ghostScene) : null), [ghostScene]);

  useEffect(() => {
    if (report) onRigReport?.(report);
  }, [onRigReport, report]);

  useEffect(() => {
    if (!avatarScene) return;
    applyProps(avatarScene, show);
    if (ghostScene) applyProps(ghostScene, show);
  }, [avatarScene, ghostScene, showKey, show]);

  useEffect(() => {
    if (!ghostMixer || !ghostScene) return;
    const clips = animations.filter((clip) => play.includes(clip.name));
    for (const clip of clips) {
      const action = ghostMixer.clipAction(clip, ghostScene);
      action.reset();
      action.setLoop(LoopRepeat, Infinity);
      action.play();
    }
    return () => {
      ghostMixer.stopAllAction();
    };
  }, [animations, ghostMixer, ghostScene, playKey, play]);

  useEffect(() => {
    const active = play
      .map((name) => actions[name])
      .filter((action): action is NonNullable<typeof action> => Boolean(action));
    for (const action of Object.values(actions)) {
      if (action && !active.includes(action)) action.stop();
    }
    if (active.length === 0) return;
    const duration = Math.max(...active.map((action) => action.getClip().duration), 0.01);
    clockRef.current.duration = duration;
    for (const action of active) {
      action.reset();
      action.enabled = true;
      action.setLoop(LoopRepeat, Infinity);
      action.play();
    }
    mixer.setTime(0);
    clockRef.current.time = 0;
    return () => {
      for (const action of active) action.stop();
    };
  }, [actions, mixer, playKey, play]);

  useEffect(() => {
    const active = play
      .map((name) => actions[name])
      .filter((action): action is NonNullable<typeof action> => Boolean(action));
    for (const action of active) {
      action.timeScale = playbackRate;
      action.paused = !playing || scrub !== null;
    }
  }, [actions, play, playbackRate, playing, scrub]);

  useEffect(() => {
    if (scrub === null) return;
    const duration = clockRef.current.duration;
    const time = Math.max(0, Math.min(duration, scrub * duration));
    mixer.setTime(time);
    clockRef.current.time = time;
  }, [mixer, scrub]);

  useFrame(() => {
    const duration = clockRef.current.duration;
    const lead = actions[play[0]];
    const time = scrub === null ? (lead ? lead.time % duration : 0) : scrub * duration;
    clockRef.current.time = time;
    if (ghostMixer) {
      const behind = time - 0.45;
      ghostMixer.setTime(behind < 0 ? behind + duration : behind);
    }
    const now = performance.now();
    if (now - uiRef.current < 120) return;
    uiRef.current = now;
    onClock?.(time, duration);
    if (!avatarScene) return;
    onAngles?.({
      kneeL: jointDegrees(avatarScene, "thigh_l", "calf_l", "foot_l"),
      kneeR: jointDegrees(avatarScene, "thigh_r", "calf_r", "foot_r"),
      elbowL: jointDegrees(avatarScene, "upperarm_l", "lowerarm_l", "hand_l"),
      elbowR: jointDegrees(avatarScene, "upperarm_r", "lowerarm_r", "hand_r"),
    });
  });

  if (!avatarScene) return null;

  return (
    <group position={[0, y, 0]} scale={scale}>
      <group ref={mount}>
        <primitive object={avatarScene} dispose={null} />
      </group>
      {ghostScene && <primitive object={ghostScene} dispose={null} />}
    </group>
  );
}
